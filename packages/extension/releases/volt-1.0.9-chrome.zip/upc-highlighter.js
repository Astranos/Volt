var upcHighlighter=(function(){"use strict";function P(r){return r}const b={matches:["<all_urls>"],runAt:"document_idle",allFrames:!0,main(){const r=(...t)=>{try{console.log("[Scout UPC Highlighter]",...t)}catch{}},u=/\b(\d{12})\b/g,x=`
      .scout-upc-highlight {
        background-color: rgba(59, 130, 246, 0.15);
        border-bottom: 2px dotted #3b82f6;
        cursor: pointer;
        padding: 1px 2px;
        border-radius: 2px;
        transition: all 0.2s ease;
        position: relative;
      }

      .scout-upc-highlight:hover {
        background-color: rgba(59, 130, 246, 0.25);
        border-bottom-style: solid;
      }

      .scout-upc-copied {
        background-color: rgba(16, 185, 129, 0.2) !important;
        border-bottom-color: #10b981 !important;
      }

      .scout-upc-tooltip {
        position: fixed;
        background-color: #1f2937;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        white-space: nowrap;
        z-index: 2147483647;
        pointer-events: none;
        opacity: 0;
        transition: opacity 0.2s ease;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
      }

      .scout-upc-tooltip.show {
        opacity: 1;
      }
    `,E=()=>{if(!document.getElementById("scout-upc-highlighter-styles")){const t=document.createElement("style");t.textContent=x,t.id="scout-upc-highlighter-styles",(document.head||document.documentElement).appendChild(t)}},h=(t,n)=>{document.querySelectorAll(".scout-upc-tooltip").forEach(e=>{e.remove()});const o=document.createElement("div");o.className="scout-upc-tooltip",o.textContent=n,document.body.appendChild(o);const i=t.getBoundingClientRect(),s=o.getBoundingClientRect();let c=i.left+i.width/2-s.width/2,a=i.top-s.height-8;c<5&&(c=5),c+s.width>window.innerWidth-5&&(c=window.innerWidth-s.width-5),a<5&&(a=i.bottom+8),o.style.left=`${c}px`,o.style.top=`${a}px`,setTimeout(()=>{o.classList.add("show")},10),setTimeout(()=>{o.classList.remove("show"),setTimeout(()=>{o.parentNode&&o.parentNode.removeChild(o)},200)},2e3)},w=async(t,n)=>{try{const o=async()=>navigator?.clipboard?.writeText?(await navigator.clipboard.writeText(t),!0):!1,i=()=>{if(!document?.body)return!1;const e=document.createElement("textarea");e.value=t,e.setAttribute("readonly","true"),e.style.position="fixed",e.style.left="-9999px",e.style.opacity="0",e.style.pointerEvents="none",document.body.appendChild(e),e.focus(),e.select();const d=document.execCommand?.("copy");return document.body.removeChild(e),!!d},s=async()=>(await new Promise((e,d)=>{try{chrome.runtime.sendMessage({action:"copyToClipboard",text:t},p=>{const y=chrome.runtime.lastError;if(y){d(y);return}if(p?.success===!1){d(new Error(p.error||"copy_failed"));return}e()})}catch(p){d(p)}}),!0),c=[()=>o().catch(e=>(r("navigator.clipboard.writeText failed",e),!1)),()=>{try{return i()}catch(e){return r("document.execCommand copy failed",e),!1}},()=>s().catch(e=>(r("Background clipboard copy failed",e),!1))];let a=!1;for(const e of c)if(await e()){a=!0;break}a?(n.classList.add("scout-upc-copied"),h(n,"UPC copied!"),r("UPC code copied to clipboard:",t)):(h(n,"Failed to copy"),r("Failed to copy UPC code after all strategies")),setTimeout(()=>{n.classList.remove("scout-upc-copied")},2e3)}catch(o){r("Failed to copy UPC code:",o),h(n,"Failed to copy")}},T=t=>{const n=t.textContent;if(!n||!u.test(n))return;const o=document.createDocumentFragment();let i=0,s;for(u.lastIndex=0;(s=u.exec(n))!==null;){s.index>i&&o.appendChild(document.createTextNode(n.substring(i,s.index)));const c=document.createElement("span"),a=s[0];c.className="scout-upc-highlight",c.textContent=a,c.setAttribute("data-upc",a),c.title=`Click to copy UPC: ${a}`,c.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation();const d=e.currentTarget.getAttribute("data-upc");w(d,c)}),c.addEventListener("mouseenter",()=>{c.classList.contains("scout-upc-copied")||h(c,"Click to copy UPC")}),o.appendChild(c),i=s.index+s[0].length}i<n.length&&o.appendChild(document.createTextNode(n.substring(i))),o.childNodes.length>0&&t.parentNode.replaceChild(o,t)},g=t=>{if(!(t.nodeType===Node.ELEMENT_NODE&&(t.tagName==="SCRIPT"||t.tagName==="STYLE"||t.tagName==="NOSCRIPT"||t.classList.contains("scout-upc-highlight")))){if(t.nodeType===Node.TEXT_NODE){T(t);return}t.childNodes&&Array.from(t.childNodes).forEach(g)}},m=()=>{document.body&&g(document.body)},v=()=>{const t=new MutationObserver(n=>{n.some(i=>i.type==="childList"&&i.addedNodes.length>0||i.type==="characterData")&&setTimeout(m,100)});return document.body&&t.observe(document.body,{childList:!0,subtree:!0,characterData:!0}),t},N=t=>{try{chrome.storage.sync.get(["cmdkSettings"],n=>{if(chrome.runtime.lastError){r("Error checking settings:",chrome.runtime.lastError),t(!0);return}const i=n.cmdkSettings?.upcHighlighter?.enabled??!0;t(i)})}catch(n){r("Failed to check settings:",n),t(!0)}},f=()=>{N(t=>{if(!t){r("UPC highlighting is disabled in settings");return}window===window.top&&r("Initializing UPC highlighter"),E(),setTimeout(m,500);const n=v();try{chrome.runtime.onMessage.addListener((o,i,s)=>{if(o.action==="upc-highlighter-settings-changed")if(o.enabled??!0)r("UPC highlighting re-enabled, reloading page"),location.reload();else{document.querySelectorAll(".scout-upc-highlight").forEach(e=>{const d=e.parentNode;d&&d.replaceChild(document.createTextNode(e.textContent),e)});const a=document.getElementById("scout-upc-highlighter-styles");a&&a.remove(),n&&n.disconnect(),r("UPC highlighting disabled")}return!0})}catch(o){r("Failed to set up message listener:",o)}})};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",f):f()}};function L(){}function l(r,...u){}const C={debug:(...r)=>l(console.debug,...r),log:(...r)=>l(console.log,...r),warn:(...r)=>l(console.warn,...r),error:(...r)=>l(console.error,...r)};return(async()=>{try{return await b.main()}catch(r){throw C.error('The unlisted script "upc-highlighter" crashed on startup!',r),r}})()})();
upcHighlighter;
var shopifyButtons=(function(){"use strict";function $(n){return n}const q={matches:["https://admin.shopify.com/*","https://*.myshopify.com/*"],runAt:"document_idle",allFrames:!1,main(){const n=(...t)=>{try{console.log("[Volt - Shopify Buttons]",...t)}catch{}},a={volt:chrome.runtime.getURL("assets/icons/volt.webp"),ebay:chrome.runtime.getURL("assets/logos/ebay.svg"),pricecharting:chrome.runtime.getURL("assets/logos/pricecharting.webp")},L=`
      .scout-quick-actions-overlay {
        position: fixed;
        z-index: 100; /* Lowered to allow modals to cover it */
        display: flex;
        flex-direction: column;
        gap: 8px;
        pointer-events: none; /* Allow clicking through gaps */
        transition: opacity 0.2s ease;
      }

      .scout-action-tab {
        width: 48px;
        height: 120px;
        border-top-left-radius: 8px;
        border-bottom-left-radius: 8px;
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        color: white;
        box-shadow: -2px 0 8px rgba(0, 0, 0, 0.1);
        pointer-events: auto;
        position: relative;
        flex-shrink: 0;
      }

      .scout-action-tab img {
        width: 32px;
        height: 32px;
        object-fit: contain;
        filter: drop-shadow(0 1px 2px rgba(0,0,0,0.1)) brightness(0) invert(1);
      }

      .scout-volt-badge {
        width: 48px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: transparent;
        pointer-events: auto;
      }

      .scout-volt-badge img {
        width: 20px;
        height: 20px;
        object-fit: contain;
        filter: none;
      }

      .scout-action-tab:hover {
        filter: brightness(0.9);
        box-shadow: -4px 0 12px rgba(0, 0, 0, 0.2);
      }

      .scout-action-tab:active {
        transform: translateX(-2px);
      }

      .scout-action-tab.disabled {
        opacity: 0.5;
        cursor: not-allowed;
        filter: grayscale(1);
        transform: none !important;
      }

      /* eBay Tab - Green */
      .scout-tab-ebay {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%); /* Green */
      }

      /* PriceCharting Tab - Blue */
      .scout-tab-pricecharting {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); /* Blue */
      }

      /* Tooltip */
      .scout-action-tab::after {
        content: attr(data-tooltip);
        position: absolute;
        left: 100%;
        top: 50%;
        transform: translateY(-50%);
        margin-left: 12px;
        background-color: #202223;
        color: white;
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 500;
        white-space: nowrap;
        opacity: 0;
        pointer-events: none;
        transition: all 0.2s ease;
        z-index: 1000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        visibility: hidden;
      }

      .scout-action-tab:hover::after {
        opacity: 1;
        visibility: visible;
        margin-left: 16px;
      }
    `,B=()=>{if(!document.getElementById("scout-quick-actions-styles")){const t=document.createElement("style");t.textContent=L,t.id="scout-quick-actions-styles",(document.head||document.documentElement).appendChild(t)}};let p=null,d=null,h=null,s=null,u=null,v=!1,w=location.href,x=!1;const I=()=>{const t=document.querySelector('input[name="title"]');if(t){const i=t.closest("form");if(i)return n("Found main product form for Shopify quick actions"),i;let o=t.parentElement;for(;o&&o!==document.body;){const e=(o.className||"").toString();if(e.includes("Polaris-ShadowBevel")||e.includes("Polaris-LegacyCard")||e.includes("Polaris-Card"))return o;if(o.tagName==="SECTION"||e.includes("Polaris-Box")){const c=window.getComputedStyle(o);if(c.backgroundColor==="rgb(255, 255, 255)"&&c.boxShadow!=="none")return o}o=o.parentElement}}return null},P=t=>{var e;if(!t)return null;const i=t.querySelector('[class*="_ReadField_"]');if(i&&!i.className.includes("placeholder"))return((e=i.textContent)==null?void 0:e.trim())||null;const o=t.querySelector("input");return o?o.value:null},b=()=>{const t=document.querySelector('input[name="title"]');d=(t==null?void 0:t.value)||null;const i=document.querySelector('[id*="metafields.custom.upc"]')||document.querySelector('[id*="metafields.custom.barcode"]')||document.querySelector('[id*="metafields.barcode"]')||Array.from(document.querySelectorAll('[id*="metafields"]')).find(o=>{const e=o.querySelector("label");return e&&(e.textContent.includes("UPC")||e.textContent.includes("Barcode"))});h=P(i)},S=t=>{u&&!u.closed&&u.close();const i=1100,o=800,e=(window.screen.width-i)/2,c=(window.screen.height-o)/2;u=window.open(t,"scout_search_popup",`width=${i},height=${o},left=${e},top=${c},resizable=yes,scrollbars=yes`)},T=()=>{if(document.getElementById("scout-quick-actions-overlay"))return;s=document.createElement("div"),s.id="scout-quick-actions-overlay",s.className="scout-quick-actions-overlay",s.style.opacity="0";const t=document.createElement("div");t.className="scout-volt-badge";const i=document.createElement("img");i.src=a.volt,i.alt="Volt",t.appendChild(i);const o=document.createElement("div");o.className="scout-action-tab scout-tab-pricecharting",o.id="scout-tab-pc";const e=document.createElement("img");e.src=a.pricecharting,e.alt="PriceCharting",o.appendChild(e),o.onclick=r=>{if(r.stopPropagation(),h){const l=`https://www.pricecharting.com/search-products?q=${encodeURIComponent(h)}&type=videogames`;S(l)}};const c=document.createElement("div");c.className="scout-action-tab scout-tab-ebay",c.id="scout-tab-ebay";const g=document.createElement("img");g.src=a.ebay,g.alt="eBay",c.appendChild(g),c.onclick=r=>{if(r.stopPropagation(),d){const l=`https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(d)}&LH_Sold=1&LH_Complete=1&_dmd=2&rt=nc`;S(l)}},s.appendChild(t),s.appendChild(o),s.appendChild(c),document.body.appendChild(s)},A=()=>{if(p||(p=I(),!p&&!v&&(v=!0,n("Could not find main product card, showing Shopify quick actions in fallback position."))),!s)return;if(!p){s.style.opacity="0";return}const t=p.getBoundingClientRect();if(t.width===0||t.height===0||t.width<300||t.height<200){s.style.opacity="0";return}const c=t.left-48,g=t.top+60;s.style.left=`${c}px`,s.style.top=`${g}px`,s.style.opacity="1";const r=document.getElementById("scout-tab-pc"),l=document.getElementById("scout-tab-ebay");r&&(h?(r.classList.remove("disabled"),r.setAttribute("data-tooltip",`Search PriceCharting with UPC: ${h}`)):(r.classList.add("disabled"),r.setAttribute("data-tooltip","No UPC found"))),l&&(d?(l.classList.remove("disabled"),l.setAttribute("data-tooltip",`Search eBay sold prices: ${d.length>40?d.slice(0,40)+"...":d}`)):(l.classList.add("disabled"),l.setAttribute("data-tooltip","No product title found")))},C=()=>{A(),requestAnimationFrame(C)},U=()=>{p=null,d=null,h=null,v=!1,n("State reset for new page navigation")},m=()=>{const t=location.href;t!==w&&(n("URL changed:",w,"->",t),w=t,U(),setTimeout(b,500),setTimeout(b,1500))},k=()=>{if(x){n("Already initialized, skipping");return}x=!0,n("Initializing Shopify Quick Actions content script"),B(),window.addEventListener("focus",()=>{u&&!u.closed&&(u.close(),u=null)}),window.addEventListener("popstate",m);const t=history.pushState,i=history.replaceState;history.pushState=function(...e){t.apply(this,e),m()},history.replaceState=function(...e){i.apply(this,e),m()},new MutationObserver(()=>{b(),m()}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value","class"]}),T(),requestAnimationFrame(C),setInterval(()=>{b(),m()},2e3)},E=()=>{chrome.storage.sync.get(["cmdkSettings"],t=>{var e;(((e=(t.cmdkSettings||{}).shopifyButtons)==null?void 0:e.enabled)??!0)&&k()})};chrome.runtime.onMessage.addListener((t,i,o)=>{if(t.action==="shopify-buttons-settings-changed")if(t.enabled)if(!document.getElementById("scout-quick-actions-overlay"))k();else{const e=document.getElementById("scout-quick-actions-overlay");e&&(e.style.display="flex")}else{const e=document.getElementById("scout-quick-actions-overlay");e&&(e.style.display="none")}}),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",E):E()}};function R(){}function f(n,...a){}const y={debug:(...n)=>f(console.debug,...n),log:(...n)=>f(console.log,...n),warn:(...n)=>f(console.warn,...n),error:(...n)=>f(console.error,...n)};return(()=>{try{}catch(a){throw y.error('Failed to initialize plugins for "shopify-buttons"',a),a}let n;try{n=q.main(),n instanceof Promise&&(n=n.catch(a=>{throw y.error('The unlisted script "shopify-buttons" crashed on startup!',a),a}))}catch(a){throw y.error('The unlisted script "shopify-buttons" crashed on startup!',a),a}return n})()})();
shopifyButtons;
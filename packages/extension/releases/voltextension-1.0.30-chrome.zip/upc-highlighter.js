var upcHighlighter=(function(){"use strict";function P(r){return r}const C={matches:["<all_urls>"],runAt:"document_idle",allFrames:!0,main(){const r=(...t)=>{try{console.log("[Scout UPC Highlighter]",...t)}catch{}},a=/\b(\d{12})\b/g,x=`
      .scout-upc-highlight {
        background-color: rgba(59, 130, 246, 0.15);
        border-bottom: 2px dotted #3b82f6;
        cursor: pointer;
        padding: 1px 2px;
        border-radius: 2px;
        transition: all 0.2s ease;
        position: relative;
      }

      .scout-upc-highlight:hover {
        background-color: rgba(59, 130, 246, 0.25);
        border-bottom-style: solid;
      }

      .scout-upc-copied {
        background-color: rgba(16, 185, 129, 0.2) !important;
        border-bottom-color: #10b981 !important;
      }

      .scout-upc-tooltip {
        position: fixed;
        background-color: #1f2937;
        color: white;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        white-space: nowrap;
        z-index: 2147483647;
        pointer-events: none;
        opacity: 0;
        transition: opacity 0.2s ease;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
      }

      .scout-upc-tooltip.show {
        opacity: 1;
      }
    `,w=()=>{if(!document.getElementById("scout-upc-highlighter-styles")){const t=document.createElement("style");t.textContent=x,t.id="scout-upc-highlighter-styles",(document.head||document.documentElement).appendChild(t)}},p=(t,i)=>{document.querySelectorAll(".scout-upc-tooltip").forEach(e=>{e.remove()});const o=document.createElement("div");o.className="scout-upc-tooltip",o.textContent=i,document.body.appendChild(o);const n=t.getBoundingClientRect(),s=o.getBoundingClientRect();let c=n.left+n.width/2-s.width/2,d=n.top-s.height-8;c<5&&(c=5),c+s.width>window.innerWidth-5&&(c=window.innerWidth-s.width-5),d<5&&(d=n.bottom+8),o.style.left=`${c}px`,o.style.top=`${d}px`,setTimeout(()=>{o.classList.add("show")},10),setTimeout(()=>{o.classList.remove("show"),setTimeout(()=>{o.parentNode&&o.parentNode.removeChild(o)},200)},2e3)},E=async(t,i)=>{try{const o=async()=>{var e;return(e=navigator==null?void 0:navigator.clipboard)!=null&&e.writeText?(await navigator.clipboard.writeText(t),!0):!1},n=()=>{var u;if(!(document!=null&&document.body))return!1;const e=document.createElement("textarea");e.value=t,e.setAttribute("readonly","true"),e.style.position="fixed",e.style.left="-9999px",e.style.opacity="0",e.style.pointerEvents="none",document.body.appendChild(e),e.focus(),e.select();const l=(u=document.execCommand)==null?void 0:u.call(document,"copy");return document.body.removeChild(e),!!l},s=async()=>(await new Promise((e,l)=>{try{chrome.runtime.sendMessage({action:"copyToClipboard",text:t},u=>{const b=chrome.runtime.lastError;if(b){l(b);return}if((u==null?void 0:u.success)===!1){l(new Error(u.error||"copy_failed"));return}e()})}catch(u){l(u)}}),!0),c=[()=>o().catch(e=>(r("navigator.clipboard.writeText failed",e),!1)),()=>{try{return n()}catch(e){return r("document.execCommand copy failed",e),!1}},()=>s().catch(e=>(r("Background clipboard copy failed",e),!1))];let d=!1;for(const e of c)if(await e()){d=!0;break}d?(i.classList.add("scout-upc-copied"),p(i,"UPC copied!"),r("UPC code copied to clipboard:",t)):(p(i,"Failed to copy"),r("Failed to copy UPC code after all strategies")),setTimeout(()=>{i.classList.remove("scout-upc-copied")},2e3)}catch(o){r("Failed to copy UPC code:",o),p(i,"Failed to copy")}},T=t=>{const i=t.textContent;if(!i||!a.test(i))return;const o=document.createDocumentFragment();let n=0,s;for(a.lastIndex=0;(s=a.exec(i))!==null;){s.index>n&&o.appendChild(document.createTextNode(i.substring(n,s.index)));const c=document.createElement("span"),d=s[0];c.className="scout-upc-highlight",c.textContent=d,c.setAttribute("data-upc",d),c.title=`Click to copy UPC: ${d}`,c.addEventListener("click",e=>{e.preventDefault(),e.stopPropagation();const l=e.currentTarget.getAttribute("data-upc");E(l,c)}),c.addEventListener("mouseenter",()=>{c.classList.contains("scout-upc-copied")||p(c,"Click to copy UPC")}),o.appendChild(c),n=s.index+s[0].length}n<i.length&&o.appendChild(document.createTextNode(i.substring(n))),o.childNodes.length>0&&t.parentNode.replaceChild(o,t)},m=t=>{if(!(t.nodeType===Node.ELEMENT_NODE&&(t.tagName==="SCRIPT"||t.tagName==="STYLE"||t.tagName==="NOSCRIPT"||t.classList.contains("scout-upc-highlight")))){if(t.nodeType===Node.TEXT_NODE){T(t);return}t.childNodes&&Array.from(t.childNodes).forEach(m)}},f=()=>{document.body&&m(document.body)},v=()=>{const t=new MutationObserver(i=>{i.some(n=>n.type==="childList"&&n.addedNodes.length>0||n.type==="characterData")&&setTimeout(f,100)});return document.body&&t.observe(document.body,{childList:!0,subtree:!0,characterData:!0}),t},N=t=>{try{chrome.storage.sync.get(["cmdkSettings"],i=>{var s;if(chrome.runtime.lastError){r("Error checking settings:",chrome.runtime.lastError),t(!0);return}const o=i.cmdkSettings,n=((s=o==null?void 0:o.upcHighlighter)==null?void 0:s.enabled)??!0;t(n)})}catch(i){r("Failed to check settings:",i),t(!0)}},y=()=>{N(t=>{if(!t){r("UPC highlighting is disabled in settings");return}window===window.top&&r("Initializing UPC highlighter"),w(),setTimeout(f,500);const i=v();try{chrome.runtime.onMessage.addListener((o,n,s)=>{if(o.action==="upc-highlighter-settings-changed")if(o.enabled??!0)r("UPC highlighting re-enabled, reloading page"),location.reload();else{document.querySelectorAll(".scout-upc-highlight").forEach(e=>{const l=e.parentNode;l&&l.replaceChild(document.createTextNode(e.textContent),e)});const d=document.getElementById("scout-upc-highlighter-styles");d&&d.remove(),i&&i.disconnect(),r("UPC highlighting disabled")}return!0})}catch(o){r("Failed to set up message listener:",o)}})};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",y):y()}};function L(){}function h(r,...a){}const g={debug:(...r)=>h(console.debug,...r),log:(...r)=>h(console.log,...r),warn:(...r)=>h(console.warn,...r),error:(...r)=>h(console.error,...r)};return(()=>{try{}catch(a){throw g.error('Failed to initialize plugins for "upc-highlighter"',a),a}let r;try{r=C.main(),r instanceof Promise&&(r=r.catch(a=>{throw g.error('The unlisted script "upc-highlighter" crashed on startup!',a),a}))}catch(a){throw g.error('The unlisted script "upc-highlighter" crashed on startup!',a),a}return r})()})();
upcHighlighter;
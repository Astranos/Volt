var shopifyButtons=(function(){"use strict";function O(s){return s}const $={matches:["https://admin.shopify.com/*","https://*.myshopify.com/*"],runAt:"document_idle",allFrames:!1,main(){const s=(...t)=>{try{console.log("[Volt - Shopify Buttons]",...t)}catch{}},d={volt:chrome.runtime.getURL("assets/icons/volt.webp"),ebay:chrome.runtime.getURL("assets/logos/ebay.svg"),pricecharting:chrome.runtime.getURL("assets/logos/pricecharting.webp")},T=`
      .scout-quick-actions-overlay {
        position: fixed;
        z-index: 100; /* Lowered to allow modals to cover it */
        display: flex;
        flex-direction: column;
        gap: 8px;
        pointer-events: none; /* Allow clicking through gaps */
        transition: opacity 0.2s ease;
      }

      .scout-action-tab {
        width: 48px;
        height: 120px;
        border-top-left-radius: 8px;
        border-bottom-left-radius: 8px;
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        color: white;
        box-shadow: -2px 0 8px rgba(0, 0, 0, 0.1);
        pointer-events: auto;
        position: relative;
        flex-shrink: 0;
      }

      .scout-action-tab img {
        width: 32px;
        height: 32px;
        object-fit: contain;
        filter: drop-shadow(0 1px 2px rgba(0,0,0,0.1)) brightness(0) invert(1);
      }

      .scout-volt-badge {
        width: 48px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: transparent;
        pointer-events: auto;
      }

      .scout-volt-badge img {
        width: 20px;
        height: 20px;
        object-fit: contain;
        filter: none;
      }

      .scout-action-tab:hover {
        filter: brightness(0.9);
        box-shadow: -4px 0 12px rgba(0, 0, 0, 0.2);
      }

      .scout-action-tab:active {
        transform: translateX(-2px);
      }

      .scout-action-tab.disabled {
        opacity: 0.5;
        cursor: not-allowed;
        filter: grayscale(1);
        transform: none !important;
      }

      /* eBay Tab - Green */
      .scout-tab-ebay {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%); /* Green */
      }

      /* PriceCharting Tab - Blue */
      .scout-tab-pricecharting {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); /* Blue */
      }

      /* Tooltip */
      .scout-action-tab::after {
        content: attr(data-tooltip);
        position: absolute;
        left: 100%;
        top: 50%;
        transform: translateY(-50%);
        margin-left: 12px;
        background-color: #202223;
        color: white;
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 500;
        white-space: nowrap;
        opacity: 0;
        pointer-events: none;
        transition: all 0.2s ease;
        z-index: 1000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        visibility: hidden;
      }

      .scout-action-tab:hover::after {
        opacity: 1;
        visibility: visible;
        margin-left: 16px;
      }
    `,I=()=>{if(!document.getElementById("scout-quick-actions-styles")){const t=document.createElement("style");t.textContent=T,t.id="scout-quick-actions-styles",(document.head||document.documentElement).appendChild(t)}};let h=null,p=null,m=null,a=null,u=null,x=!1,C=location.href,q=!1;const S=()=>{const t=document.querySelector('input[name="title"], input[id*="title" i], input[aria-label="Title"], input[placeholder="Title"]');if(t)return t;const i=document.querySelector('s-internal-text-field[name="title"], s-text-field[name="title"], [name="title"][label="Title"]');if(i)return i;const o=Array.from(document.querySelectorAll("label")).find(r=>{var c;return((c=r.textContent)==null?void 0:c.trim().toLowerCase())==="title"}),e=o==null?void 0:o.getAttribute("for");if(e){const r=document.getElementById(e);if((r==null?void 0:r.tagName)==="INPUT")return r}const n=o==null?void 0:o.closest("div");return(n==null?void 0:n.querySelector("input"))||null},R=t=>{var n,r,c,l;if(!t)return"";const i=t.value||((n=t.getAttribute)==null?void 0:n.call(t,"value"))||"";if(i)return String(i).trim();const o=(r=t.querySelector)==null?void 0:r.call(t,"input");if(o!=null&&o.value)return o.value.trim();const e=(l=(c=t.shadowRoot)==null?void 0:c.querySelector)==null?void 0:l.call(c,"input");return e!=null&&e.value?e.value.trim():""},P=t=>{if(!t||t===document.body)return!1;const i=t.getBoundingClientRect();if(i.width<300||i.height<120)return!1;const o=(t.className||"").toString();if(o.includes("Polaris-ShadowBevel")||o.includes("Polaris-LegacyCard")||o.includes("Polaris-Card"))return!0;const e=window.getComputedStyle(t);return e.backgroundColor==="rgb(255, 255, 255)"&&(e.boxShadow!=="none"||e.borderRadius!=="0px"||e.borderColor!=="rgba(0, 0, 0, 0)")},_=()=>{const t=S();if(t){const e=t.closest(".Polaris-Layout__Section");if(e)return e;let n=t.parentElement;for(;n&&n!==document.body;){if(P(n))return n;n=n.parentElement}}const o=Array.from(document.querySelectorAll('main [class*="Polaris-ShadowBevel"], main [class*="Polaris-LegacyCard"], main [class*="Polaris-Card"], main section')).find(e=>{if(!P(e))return!1;const n=e.textContent||"";return n.includes("Title")&&n.includes("Description")});return o||null},U=t=>{var e;if(!t)return null;const i=t.querySelector('[class*="_ReadField_"]');if(i&&!i.className.includes("placeholder"))return((e=i.textContent)==null?void 0:e.trim())||null;const o=t.querySelector("input");return o?o.value:null},f=()=>{var o,e;const t=S();p=R(t)||((e=(o=document.querySelector("h1"))==null?void 0:o.textContent)==null?void 0:e.replace(/\s+Active$/,""))||null;const i=document.querySelector('[id*="metafields.custom.upc"]')||document.querySelector('[id*="metafields.custom.barcode"]')||document.querySelector('[id*="metafields.barcode"]')||Array.from(document.querySelectorAll('[id*="metafields"]')).find(n=>{const r=n.querySelector("label");return r&&(r.textContent.includes("UPC")||r.textContent.includes("Barcode"))});m=U(i)},E=t=>{const e=window.screen.width/2,n=window.screen.height/2;try{chrome.runtime.sendMessage({action:"openPreviewPopup",url:t,x:e,y:n},()=>{if(!chrome.runtime.lastError)return;u&&!u.closed&&u.close();const c=e-1100/2,l=n-800/2;u=window.open(t,"scout_search_popup",`width=1100,height=800,left=${c},top=${l},resizable=yes,scrollbars=yes`)})}catch{u&&!u.closed&&u.close();const c=e-1100/2,l=n-800/2;u=window.open(t,"scout_search_popup",`width=1100,height=800,left=${c},top=${l},resizable=yes,scrollbars=yes`)}},M=()=>{if(document.getElementById("scout-quick-actions-overlay"))return;a=document.createElement("div"),a.id="scout-quick-actions-overlay",a.className="scout-quick-actions-overlay",a.style.opacity="0";const t=document.createElement("div");t.className="scout-volt-badge";const i=document.createElement("img");i.src=d.volt,i.alt="Volt",t.appendChild(i);const o=document.createElement("div");o.className="scout-action-tab scout-tab-pricecharting",o.id="scout-tab-pc";const e=document.createElement("img");e.src=d.pricecharting,e.alt="PriceCharting",o.appendChild(e),o.onclick=c=>{if(c.stopPropagation(),f(),m){const l=`https://www.pricecharting.com/search-products?q=${encodeURIComponent(m)}&type=videogames`;E(l)}};const n=document.createElement("div");n.className="scout-action-tab scout-tab-ebay",n.id="scout-tab-ebay";const r=document.createElement("img");r.src=d.ebay,r.alt="eBay",n.appendChild(r),n.onclick=c=>{if(c.stopPropagation(),f(),p){const l=`https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(p)}&LH_Sold=1&LH_Complete=1&_dmd=2&rt=nc`;E(l)}},a.appendChild(t),a.appendChild(o),a.appendChild(n),document.body.appendChild(a)},N=()=>{if((!h||!document.contains(h))&&(h=_(),!h&&!x&&(x=!0,s("Could not find main product card, showing Shopify quick actions in fallback position."))),!a)return;if(!h){if(F()){const k=S(),b=k==null?void 0:k.getBoundingClientRect();b&&b.width>0&&b.height>0?(a.style.left=`${Math.max(16,b.left-64)}px`,a.style.top=`${Math.max(96,b.top-28)}px`,a.style.opacity="1"):a.style.opacity="0"}else a.style.opacity="0";return}const t=h.getBoundingClientRect();if(t.width===0||t.height===0||t.width<300||t.height<200){a.style.opacity="0";return}const r=Math.max(16,t.left-48-8),c=Math.max(96,t.top+24);a.style.left=`${r}px`,a.style.top=`${c}px`,a.style.opacity="1";const l=document.getElementById("scout-tab-pc"),y=document.getElementById("scout-tab-ebay");l&&(m?(l.classList.remove("disabled"),l.setAttribute("data-tooltip",`Search PriceCharting with UPC: ${m}`)):(l.classList.add("disabled"),l.setAttribute("data-tooltip","No UPC found"))),y&&(p?(y.classList.remove("disabled"),y.setAttribute("data-tooltip",`Search eBay sold prices: ${p.length>40?p.slice(0,40)+"...":p}`)):(y.classList.add("disabled"),y.setAttribute("data-tooltip","No product title found")))},B=()=>{N(),requestAnimationFrame(B)},z=()=>{h=null,p=null,m=null,x=!1,s("State reset for new page navigation")},F=()=>{const t=location.href;return/\/products\/\d+/.test(t)},g=()=>{const t=location.href;t!==C&&(s("URL changed:",C,"->",t),C=t,z(),setTimeout(f,500),setTimeout(f,1500))},L=()=>{if(q){s("Already initialized, skipping");return}q=!0,s("Initializing Shopify Quick Actions content script"),I(),window.addEventListener("focus",()=>{u&&!u.closed&&(u.close(),u=null)}),window.addEventListener("popstate",g);const t=history.pushState,i=history.replaceState;history.pushState=function(...e){t.apply(this,e),g()},history.replaceState=function(...e){i.apply(this,e),g()},new MutationObserver(()=>{f(),g()}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value","class"]}),M(),requestAnimationFrame(B),setInterval(()=>{f(),g()},2e3)},A=()=>{chrome.storage.sync.get(["cmdkSettings"],t=>{var e;(((e=(t.cmdkSettings||{}).shopifyButtons)==null?void 0:e.enabled)??!0)&&L()})};chrome.runtime.onMessage.addListener((t,i,o)=>{if(t.action==="shopify-buttons-settings-changed")if(t.enabled)if(!document.getElementById("scout-quick-actions-overlay"))L();else{const e=document.getElementById("scout-quick-actions-overlay");e&&(e.style.display="flex")}else{const e=document.getElementById("scout-quick-actions-overlay");e&&(e.style.display="none")}}),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",A):A()}};function j(){}function w(s,...d){}const v={debug:(...s)=>w(console.debug,...s),log:(...s)=>w(console.log,...s),warn:(...s)=>w(console.warn,...s),error:(...s)=>w(console.error,...s)};return(()=>{try{}catch(d){throw v.error('Failed to initialize plugins for "shopify-buttons"',d),d}let s;try{s=$.main(),s instanceof Promise&&(s=s.catch(d=>{throw v.error('The unlisted script "shopify-buttons" crashed on startup!',d),d}))}catch(d){throw v.error('The unlisted script "shopify-buttons" crashed on startup!',d),d}return s})()})();
shopifyButtons;
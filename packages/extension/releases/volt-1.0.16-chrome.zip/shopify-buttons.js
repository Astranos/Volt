var shopifyButtons=(function(){"use strict";function R(i){return i}const E={matches:["https://admin.shopify.com/*","https://*.myshopify.com/*"],runAt:"document_idle",allFrames:!1,main(){const i=(...t)=>{try{console.log("[Volt - Shopify Buttons]",...t)}catch{}},f={volt:chrome.runtime.getURL("assets/icons/volt.webp"),ebay:chrome.runtime.getURL("assets/logos/ebay.svg"),pricecharting:chrome.runtime.getURL("assets/logos/pricecharting.webp")},L=`
      .scout-quick-actions-overlay {
        position: fixed;
        z-index: 100; /* Lowered to allow modals to cover it */
        display: flex;
        flex-direction: column;
        gap: 8px;
        pointer-events: none; /* Allow clicking through gaps */
        transition: opacity 0.2s ease;
      }

      .scout-action-tab {
        width: 48px;
        height: 120px;
        border-top-left-radius: 8px;
        border-bottom-left-radius: 8px;
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        color: white;
        box-shadow: -2px 0 8px rgba(0, 0, 0, 0.1);
        pointer-events: auto;
        position: relative;
        flex-shrink: 0;
      }

      .scout-action-tab img {
        width: 32px;
        height: 32px;
        object-fit: contain;
        filter: drop-shadow(0 1px 2px rgba(0,0,0,0.1)) brightness(0) invert(1);
      }

      .scout-volt-badge {
        width: 48px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: transparent;
        pointer-events: auto;
      }

      .scout-volt-badge img {
        width: 20px;
        height: 20px;
        object-fit: contain;
        filter: none;
      }

      .scout-action-tab:hover {
        filter: brightness(0.9);
        box-shadow: -4px 0 12px rgba(0, 0, 0, 0.2);
      }

      .scout-action-tab:active {
        transform: translateX(-2px);
      }

      .scout-action-tab.disabled {
        opacity: 0.5;
        cursor: not-allowed;
        filter: grayscale(1);
        transform: none !important;
      }

      /* eBay Tab - Green */
      .scout-tab-ebay {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%); /* Green */
      }

      /* PriceCharting Tab - Blue */
      .scout-tab-pricecharting {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); /* Blue */
      }

      /* Tooltip */
      .scout-action-tab::after {
        content: attr(data-tooltip);
        position: absolute;
        left: 100%;
        top: 50%;
        transform: translateY(-50%);
        margin-left: 12px;
        background-color: #202223;
        color: white;
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 500;
        white-space: nowrap;
        opacity: 0;
        pointer-events: none;
        transition: all 0.2s ease;
        z-index: 1000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        visibility: hidden;
      }

      .scout-action-tab:hover::after {
        opacity: 1;
        visibility: visible;
        margin-left: 16px;
      }
    `,B=()=>{if(!document.getElementById("scout-quick-actions-styles")){const t=document.createElement("style");t.textContent=L,t.id="scout-quick-actions-styles",(document.head||document.documentElement).appendChild(t)}};let u=null,l=null,p=null,s=null,d=null,y=!1,v=location.href,w=!1;const I=()=>{const t=document.querySelector('input[name="title"]');if(t){const n=t.closest("form");if(n)return i("Found main product form for Shopify quick actions"),n;let e=t.parentElement;for(;e&&e!==document.body;){const o=(e.className||"").toString();if(o.includes("Polaris-ShadowBevel")||o.includes("Polaris-LegacyCard")||o.includes("Polaris-Card"))return e;if(e.tagName==="SECTION"||o.includes("Polaris-Box")){const a=window.getComputedStyle(e);if(a.backgroundColor==="rgb(255, 255, 255)"&&a.boxShadow!=="none")return e}e=e.parentElement}}return null},P=t=>{if(!t)return null;const n=t.querySelector('[class*="_ReadField_"]');if(n&&!n.className.includes("placeholder"))return n.textContent?.trim()||null;const e=t.querySelector("input");return e?e.value:null},b=()=>{l=document.querySelector('input[name="title"]')?.value||null;const n=document.querySelector('[id*="metafields.custom.upc"]')||document.querySelector('[id*="metafields.custom.barcode"]')||document.querySelector('[id*="metafields.barcode"]')||Array.from(document.querySelectorAll('[id*="metafields"]')).find(e=>{const o=e.querySelector("label");return o&&(o.textContent.includes("UPC")||o.textContent.includes("Barcode"))});p=P(n)},x=t=>{d&&!d.closed&&d.close();const n=1100,e=800,o=(window.screen.width-n)/2,a=(window.screen.height-e)/2;d=window.open(t,"scout_search_popup",`width=${n},height=${e},left=${o},top=${a},resizable=yes,scrollbars=yes`)},A=()=>{if(document.getElementById("scout-quick-actions-overlay"))return;s=document.createElement("div"),s.id="scout-quick-actions-overlay",s.className="scout-quick-actions-overlay",s.style.opacity="0";const t=document.createElement("div");t.className="scout-volt-badge";const n=document.createElement("img");n.src=f.volt,n.alt="Volt",t.appendChild(n);const e=document.createElement("div");e.className="scout-action-tab scout-tab-pricecharting",e.id="scout-tab-pc";const o=document.createElement("img");o.src=f.pricecharting,o.alt="PriceCharting",e.appendChild(o),e.onclick=c=>{if(c.stopPropagation(),p){const r=`https://www.pricecharting.com/search-products?q=${encodeURIComponent(p)}&type=videogames`;x(r)}};const a=document.createElement("div");a.className="scout-action-tab scout-tab-ebay",a.id="scout-tab-ebay";const h=document.createElement("img");h.src=f.ebay,h.alt="eBay",a.appendChild(h),a.onclick=c=>{if(c.stopPropagation(),l){const r=`https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(l)}&LH_Sold=1&LH_Complete=1&_dmd=2&rt=nc`;x(r)}},s.appendChild(t),s.appendChild(e),s.appendChild(a),document.body.appendChild(s)},T=()=>{if(u||(u=I(),!u&&!y&&(y=!0,i("Could not find main product card, showing Shopify quick actions in fallback position."))),!s)return;if(!u){s.style.opacity="0";return}const t=u.getBoundingClientRect();if(t.width===0||t.height===0||t.width<300||t.height<200){s.style.opacity="0";return}const a=t.left-48,h=t.top+60;s.style.left=`${a}px`,s.style.top=`${h}px`,s.style.opacity="1";const c=document.getElementById("scout-tab-pc"),r=document.getElementById("scout-tab-ebay");c&&(p?(c.classList.remove("disabled"),c.setAttribute("data-tooltip",`Search PriceCharting with UPC: ${p}`)):(c.classList.add("disabled"),c.setAttribute("data-tooltip","No UPC found"))),r&&(l?(r.classList.remove("disabled"),r.setAttribute("data-tooltip",`Search eBay sold prices: ${l.length>40?l.slice(0,40)+"...":l}`)):(r.classList.add("disabled"),r.setAttribute("data-tooltip","No product title found")))},S=()=>{T(),requestAnimationFrame(S)},U=()=>{u=null,l=null,p=null,y=!1,i("State reset for new page navigation")},m=()=>{const t=location.href;t!==v&&(i("URL changed:",v,"->",t),v=t,U(),setTimeout(b,500),setTimeout(b,1500))},C=()=>{if(w){i("Already initialized, skipping");return}w=!0,i("Initializing Shopify Quick Actions content script"),B(),window.addEventListener("focus",()=>{d&&!d.closed&&(d.close(),d=null)}),window.addEventListener("popstate",m);const t=history.pushState,n=history.replaceState;history.pushState=function(...o){t.apply(this,o),m()},history.replaceState=function(...o){n.apply(this,o),m()},new MutationObserver(()=>{b(),m()}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value","class"]}),A(),requestAnimationFrame(S),setInterval(()=>{b(),m()},2e3)},k=()=>{chrome.storage.sync.get(["cmdkSettings"],t=>{((t.cmdkSettings||{}).shopifyButtons?.enabled??!0)&&C()})};chrome.runtime.onMessage.addListener((t,n,e)=>{if(t.action==="shopify-buttons-settings-changed")if(t.enabled)if(!document.getElementById("scout-quick-actions-overlay"))C();else{const o=document.getElementById("scout-quick-actions-overlay");o&&(o.style.display="flex")}else{const o=document.getElementById("scout-quick-actions-overlay");o&&(o.style.display="none")}}),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",k):k()}};function _(){}function g(i,...f){}const q={debug:(...i)=>g(console.debug,...i),log:(...i)=>g(console.log,...i),warn:(...i)=>g(console.warn,...i),error:(...i)=>g(console.error,...i)};return(async()=>{try{return await E.main()}catch(i){throw q.error('The unlisted script "shopify-buttons" crashed on startup!',i),i}})()})();
shopifyButtons;
var pricechartingGame=(function(){"use strict";function F(e){return e}const O="sidepanel.html",S="__scoutSidePanelCtx__";function E(){const e=globalThis;return e[S]||(e[S]={state:{open:!1,tool:null},listenersAttached:!1}),e[S]}function C(e){if(e.tabId!==void 0)return;const n=()=>{if(e.tabId===void 0)try{chrome.runtime.sendMessage({action:"getSidePanelStateForTab"},t=>{!chrome.runtime.lastError&&t?.success?(typeof t?.tabId=="number"&&(e.tabId=t.tabId,console.log(`[Scout] Sidepanel context initialized with tabId: ${e.tabId}`)),t?.state&&(e.state=T(t.state))):setTimeout(n,1e3)})}catch{setTimeout(n,2e3)}};n(),N(e)}function N(e){if(!e.listenersAttached){try{chrome.runtime.onMessage.addListener((n,t,r)=>(n?.action==="sidePanelStateSync"&&(e.state=T(n?.state),r({ok:!0})),!1))}catch{}e.listenersAttached=!0}}function T(e){return!e||typeof e!="object"?{open:!1,tool:null}:{open:!!e.open,tool:typeof e.tool=="string"?e.tool:null}}function k(e){if(chrome?.sidePanel?.setOptions)try{const n={enabled:!0,path:O};typeof e=="number"&&(n.tabId=e),chrome.sidePanel.setOptions(n,()=>{const t=chrome.runtime.lastError;t&&console.warn("[Scout] setOptions warning:",t.message)})}catch{}}function q(e){return new Promise((n,t)=>{if(!chrome?.sidePanel?.open){t(new Error("sidePanel API unavailable"));return}try{const r={};typeof e=="number"&&(r.tabId=e),chrome.sidePanel.open(r,()=>{const s=chrome.runtime.lastError;s?t(s):n()})}catch(r){t(r)}})}function x(e,n,t,r,s){try{chrome.runtime.sendMessage({action:"sidePanelToggleResult",status:e,tabId:n,tool:t,source:r,error:s},()=>{chrome.runtime.lastError})}catch{}}function w(){const e=!!chrome?.sidePanel?.open;return console.log(`[Scout] sidePanel API available: ${e}, tabId: ${E().tabId}`),e}function M(){try{const e=E();C(e)}catch{}}function B(e,n){if(!w())return Promise.reject(new Error("sidePanel API unavailable"));const t=E();C(t);const r=t.tabId;return t.state,new Promise((s,b)=>{try{chrome.storage?.local?.set?.({sidePanelTool:e,sidePanelUrl:null})}catch{}t.state={open:!0,tool:e},k(r),q(r).then(()=>{x("opened",r,e,n?.source),s("opened")}).catch(l=>{console.error("[Scout] execOpen failed:",l),t.state={open:!1,tool:null},x("error",r,e,n?.source,l?.message),b(l)})})}const G={matches:["https://www.pricecharting.com/game/*"],runAt:"document_idle",allFrames:!1,main(){const e=(...o)=>{try{console.log("[Scout - PriceCharting Game]",...o)}catch{}};e("Content script loaded on game page");const n=`
      .scout-add-to-lot-btn {
        background: #22c55e !important;
        color: white !important;
        border: none !important;
        padding: 4px 8px !important;
        border-radius: 4px !important;
        font-size: 11px !important;
        font-weight: 600 !important;
        cursor: pointer !important;
        transition: all 0.2s ease !important;
        white-space: nowrap !important;
        display: inline-block !important;
        text-decoration: none !important;
        line-height: 1.2 !important;
      }
      .scout-add-to-lot-btn:hover {
        background: #16a34a !important;
        transform: translateY(-1px) !important;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1) !important;
      }
      .scout-add-to-lot-btn:active {
        transform: translateY(0) !important;
      }
      .scout-col-header {
        font-size: 11px !important;
        color: #666 !important;
        text-align: center !important;
        width: 100px !important;
      }
      .scout-pc-added-flash {
        animation: scout-pc-flash 0.5s ease;
      }
      @keyframes scout-pc-flash {
        0% { background: rgba(34, 197, 94, 0.5) !important; }
        100% { background: transparent !important; }
      }
    `,t=()=>{if(!document.getElementById("scout-pc-game-styles")){const o=document.createElement("style");o.textContent=n,o.id="scout-pc-game-styles",(document.head||document.documentElement).appendChild(o)}},r=o=>{const i=o.match(/[\d,.]+/);return i?parseFloat(i[0].replace(/,/g,"")):0},s=()=>{const o=document.querySelector("#product_name");if(!o)return null;const m=o.querySelector("a")?.textContent?.trim()||"";let d="";for(const P of o.childNodes)P.nodeType===Node.TEXT_NODE&&(d+=P.textContent);d=d.trim();let p="";const c=document.querySelectorAll(".scout-upc-highlight[data-upc]");return c.length>0&&(p=c[0].getAttribute("data-upc")||""),{title:d,console:m,url:window.location.href,upc:p}},b={"completed-auctions-used":"Loose","completed-auctions-cib":"CIB","completed-auctions-new":"New","completed-auctions-graded":"Graded","completed-auctions-box-only":"Box Only","completed-auctions-manual-only":"Manual Only"},l=()=>{const o=s();if(!o){e("Could not get game info from page");return}document.querySelectorAll("table.hoverable-rows.sortable").forEach(m=>{let d="Loose";const p=m.closest("div[class*='completed-auctions-']");if(p){for(const[a,u]of Object.entries(b))if(p.classList.contains(a)){d=u;break}}const c=m.querySelector("thead tr");if(c&&!c.querySelector(".scout-col-header")){const a=document.createElement("th");a.className="scout-col-header",a.textContent="";const u=c.cells[c.cells.length-1];u?c.insertBefore(a,u):c.appendChild(a)}m.querySelectorAll("tbody tr").forEach(a=>{if(a.querySelector(".scout-add-to-lot-btn"))return;const u=a.querySelector("td.numeric span.js-price");if(!u)return;const D=u.textContent?.trim()||"",A=r(D);if(A<=0)return;const y=document.createElement("td");y.className="numeric";const h=document.createElement("button");h.className="scout-add-to-lot-btn",h.textContent="Add To Game Lot",h.type="button",h.addEventListener("click",async L=>{L.preventDefault(),L.stopPropagation();const v={id:Math.random().toString(36).substring(7),title:o.title,console:o.console,price:A,condition:d,url:window.location.href,saleTitle:a.querySelector("td.title a")?.textContent?.trim()||"",upc:o.upc||""};e("Adding sale item to lot:",v);try{chrome.runtime.sendMessage({type:"PC_ITEM_SELECTED",data:v});try{w()?B("price-charting-tool",{source:"pricecharting-game",mode:"open"}).catch(f=>{e("Sidepanel trigger error from PriceCharting game:",f)}):chrome.runtime.sendMessage({action:"openInSidebar",tool:"price-charting-tool",mode:"open"})}catch(f){e("Error triggering sidepanel from PriceCharting game:",f)}a.classList.add("scout-pc-added-flash"),setTimeout(()=>{a.classList.remove("scout-pc-added-flash")},500)}catch(f){e("Error sending message:",f)}}),y.appendChild(h);const _=a.cells[a.cells.length-1];_?a.insertBefore(y,_):a.appendChild(y)})})},I=()=>{e("Initializing PriceCharting game page enhancements");try{M()}catch{}t(),setTimeout(()=>{l(),e("Initial setup complete")},500);const o=new MutationObserver(()=>{l()}),i=document.querySelector("#content")||document.body;i&&(e("Observing content area for changes"),o.observe(i,{childList:!0,subtree:!0}))};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",I):I()}};function Y(){}function g(e,...n){}const z={debug:(...e)=>g(console.debug,...e),log:(...e)=>g(console.log,...e),warn:(...e)=>g(console.warn,...e),error:(...e)=>g(console.error,...e)};return(async()=>{try{return await G.main()}catch(e){throw z.error('The unlisted script "pricecharting-game" crashed on startup!',e),e}})()})();
pricechartingGame;